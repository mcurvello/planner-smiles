package com.ccr.chance;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ChanceApplicationTests {

	@Test
	void contextLoads() {
	}

}
