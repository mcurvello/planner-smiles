package com.ccr.chance.entities;

public enum InterestArea {

	DESIGN, MANAGEMENT, DEVELOPMENT, FINANCE, BUSINESS;
}
