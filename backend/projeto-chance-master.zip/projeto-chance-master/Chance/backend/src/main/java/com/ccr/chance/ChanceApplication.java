package com.ccr.chance;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ChanceApplication {

	public static void main(String[] args) {
		SpringApplication.run(ChanceApplication.class, args);
	}

}
