package com.ccr.chance.entities;

public enum DefianceStatus {

	PENDING, DELIVERED;
}
